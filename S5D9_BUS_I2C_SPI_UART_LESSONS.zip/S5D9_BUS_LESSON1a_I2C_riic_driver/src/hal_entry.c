/*

    Project: Bus Lesson with iic Driver
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    1/1/18

    SSP version: 1.30
    E2 Studio version: 5.4.0.023

    Description: Use i2c bus to serially communicate to the sensor (BMC150) bidirectional mode.
                 Three commands are used in this example: XYZ postions read, chip ID read, temperature read.

    Configuration: Grove B (Port1) 1. P1_0/1_1(I2C peripheral interface)   Use iic1 (channel 1)
                   Driver mode: r_iic driver
                   Speed: Standard (100K hz)
                   Slave address: 0x11

*/

/* HAL-only entry function */
#include "hal_data.h"

int count = 0;

void hal_entry(void)
{
    uint8_t buf[20];
    ssp_err_t err;

    g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_13, false);


    //read acceleration
    err = g_i2c0.p_api->open(g_i2c0.p_ctrl, g_i2c0.p_cfg);
    if (err)
        g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_13, true);



    while (1)
     {
         // read xyz value
         buf[0] = 0x02;
         err = g_i2c0.p_api->write(g_i2c0.p_ctrl, buf, 1, false);
         if (err)
             g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_13, true);
         err = g_i2c0.p_api->read(g_i2c0.p_ctrl, &buf[7], 6, false);
         if (err)
             g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_13, true);

         //read chip id
         buf[0] = 0x00;
         err = g_i2c0.p_api->write(g_i2c0.p_ctrl, buf, 1, false);
         if (err)
             g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_13, true);

         err = g_i2c0.p_api->read(g_i2c0.p_ctrl, &buf[7], 1, false);
         if (err)
             g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_13, true);

         //read temperature
         buf[0] = 0x08;
         err = g_i2c0.p_api->write(g_i2c0.p_ctrl, buf, 1, false);
         if (err)
             g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_13, true);

         err = g_i2c0.p_api->read(g_i2c0.p_ctrl, &buf[7], 1, false);
         if (err)
             g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_13, true);

       }

}
