/* generated configuration header file - do not edit */
#ifndef UX_USER_H_
#define UX_USER_H_
#if (SYNERGY_NOT_DEFINED)
#include "ux_src_user.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "ux_device_class_storage_user.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "ux_host_class_storage_user.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "ux_host_class_hid_user.h"
#endif
#endif /* UX_USER_H_ */
