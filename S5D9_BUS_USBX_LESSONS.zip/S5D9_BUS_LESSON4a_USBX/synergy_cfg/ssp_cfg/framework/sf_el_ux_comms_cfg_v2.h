/* generated configuration header file - do not edit */
#ifndef SF_EL_UX_COMMS_CFG_V2_H_
#define SF_EL_UX_COMMS_CFG_V2_H_
#define SF_EL_UX_COMMS_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define SF_EL_UX_COMMS_CFG_BUFFER_MAX_LENGTH (128)
#define SF_EL_UX_COMMS_CFG_BUFFER_TIMEOUT_COUNT (1000)
#endif /* SF_EL_UX_COMMS_CFG_V2_H_ */
