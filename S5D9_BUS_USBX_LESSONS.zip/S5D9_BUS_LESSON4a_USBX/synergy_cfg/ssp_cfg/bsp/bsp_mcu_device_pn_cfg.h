/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FS5D97E2A01CLK
#define BSP_ROM_SIZE_BYTES (2097152)
#define BSP_RAM_SIZE_BYTES (655360)
#define BSP_DATA_FLASH_SIZE_BYTES (65536)
#define BSP_PACKAGE_LGA
#define BSP_PACKAGE_PINS (145)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
