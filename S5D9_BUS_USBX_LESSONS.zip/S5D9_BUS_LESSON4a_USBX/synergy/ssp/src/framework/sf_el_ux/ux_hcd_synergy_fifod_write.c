/**************************************************************************/ 
/*                                                                        */ 
/*            Copyright (c) 1996-2012 by Express Logic Inc.               */ 
/*                                                                        */ 
/*  This software is copyrighted by and is the sole property of Express   */ 
/*  Logic, Inc.  All rights, title, ownership, or other interests         */ 
/*  in the software remain the property of Express Logic, Inc.  This      */ 
/*  software may only be used in accordance with the corresponding        */ 
/*  license agreement.  Any unauthorized use, duplication, transmission,  */ 
/*  distribution, or disclosure of this software is expressly forbidden.  */ 
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */ 
/*  written consent of Express Logic, Inc.                                */ 
/*                                                                        */ 
/*  Express Logic, Inc. reserves the right to modify this software        */ 
/*  without notice.                                                       */ 
/*                                                                        */ 
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               www.expresslogic.com          */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/

/***********************************************************************************************************************
 * Copyright [2017] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 * 
 * This file is part of Renesas SynergyTM Software Package (SSP)
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas SSP license agreement. Unless otherwise agreed in an SSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
 **********************************************************************************************************************/

/**************************************************************************/
/**************************************************************************/
/**                                                                       */ 
/** USBX Component                                                        */ 
/**                                                                       */
/**   SYNERGY Controller Driver                                           */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/


/* Include necessary system files.  */

#define UX_SOURCE_CODE

#include "ux_api.h"
#include "ux_hcd_synergy.h"
#include "ux_utility.h"
#include "r_transfer_api.h"

VOID    ux_hcd_synergy_fifo_write_software_copy(UX_HCD_SYNERGY *hcd_synergy,
                                    ULONG payload_length, UCHAR *payload_buffer, VOID * fifo_addr, ULONG fifo_sel);
VOID    ux_hcd_synergy_fifo_write_software_copy_remaining_bytes(UX_HCD_SYNERGY *hcd_synergy,
                                    ULONG payload_length, UCHAR *payload_buffer, VOID * fifo_addr);

/*******************************************************************************************************************//**
 * @addtogroup sf_el_ux
 * @{
 **********************************************************************************************************************/

/**************************************************************************/ 
/*                                                                        */ 
/*  FUNCTION                                               RELEASE        */ 
/*                                                                        */ 
/*    ux_hcd_synergy_fofod_write                          PORTABLE C      */
/*                                                           5.6          */ 
/*  AUTHOR                                                                */ 
/*                                                                        */ 
/*    Thierry Giron, Express Logic Inc.                                   */ 
/*                                                                        */ 
/*  DESCRIPTION                                                           */ 
/*                                                                        */ 
/*    This function writes a buffer to FIFOD0 or FIFOD1                   */ 
/*                                                                        */ 
/*  INPUT                                                                 */ 
/*                                                                        */ 
/*    hcd_synergy                           Pointer to Synergy controller */
/*    ed                                    Register to the ed            */ 
/*                                                                        */ 
/*  OUTPUT                                                                */ 
/*                                                                        */ 
/*    status                                                              */ 
/*                                                                        */ 
/*  CALLS                                                                 */ 
/*                                                                        */ 
/*    None                                                                */ 
/*                                                                        */ 
/*  CALLED BY                                                             */ 
/*                                                                        */ 
/*    Synergy Controller Driver                                           */
/*                                                                        */ 
/*  RELEASE HISTORY                                                       */ 
/*                                                                        */ 
/*    DATE              NAME                      DESCRIPTION             */ 
/*                                                                        */ 
/*  10-10-2012     TCRG                     Initial Version 5.6           */ 
/*                                                                        */ 
/**************************************************************************/

/***********************************************************************************************************************
 * Functions
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief  This function writes a buffer data to FIFOD0 or FIFOD1.
 *
 * @param[in,out]  hcd_synergy : Pointer to a HCD control block
 * @param[in,out]  ed          : Pointer to Synergy ED structure
 *
 * @retval UX_ERROR                        Unable to access FIFO successfully.
 * @retval UX_SYNERGY_HC_FIFO_WRITE_END    Writing at ends.
 * @retval UX_SYNERGY_HC_FIFO_WRITE_SHORT  Writing short data.
 * @retval UX_SYNERGY_HC_FIFO_WRITING      Doing multiple writes.
 **********************************************************************************************************************/
UINT  ux_hcd_synergy_fifod_write(UX_HCD_SYNERGY *hcd_synergy, UX_SYNERGY_ED *ed)
{
    UX_SYNERGY_TD * td;
    ULONG           fifo_access_status;
    ULONG           max_packet_size;
    ULONG           data_buffer_size;
    ULONG           payload_length;
    UINT            status;
    UCHAR         * payload_buffer;
    ULONG           fifo_sel;
    VOID          * fifo_addr;
    ULONG           fifo_ctrl;
    ULONG           transfer_length_width = 0;
    ULONG           synergy_register;

    /* Get the Fifo access status.  */
    fifo_access_status =  ux_hcd_synergy_fifo_port_change(hcd_synergy, ed, 0UL);

    /* Check Status.  */
    if (fifo_access_status == (ULONG)UX_ERROR)
    {
        /* We have an error. Abort.  */
        return (UINT)UX_ERROR;
    }

    /* Get the data buffer size.  */
    data_buffer_size = ux_hcd_synergy_data_buffer_size(hcd_synergy, ed);

    /* Get the max packet size for this endpoint.  */
    max_packet_size = ed -> ux_synergy_ed_endpoint -> ux_endpoint_descriptor.wMaxPacketSize;

    /* Get the TD used for this transfer.  */
    td =  ed->ux_synergy_ed_head_td;

    /* Check if this transfer takes more than one packet.  */
    if (td -> ux_synergy_td_length <= max_packet_size) 
    {
        /* Set the payload to the TD payload length.  */
        payload_length =  td -> ux_synergy_td_length;

        /* Set Status to write ends.  */
        status = (UINT)UX_SYNERGY_HC_FIFO_WRITE_END;

        /* Check for 0 packet.  */
        if ((td -> ux_synergy_td_length == 0UL) || ((td -> ux_synergy_td_length % max_packet_size ) != 0UL))
        {
            /* Set Status to write short.  */
            status = (UINT)UX_SYNERGY_HC_FIFO_WRITE_SHORT;
        }
    }
    else
    {
        /* We are doing a multi write.  */
        status = (UINT)UX_SYNERGY_HC_FIFO_WRITING;


#if defined(R_USBHS_BASE)
        /* Payload length is the FIFO size.  */
        if (R_USBHS_BASE == hcd_synergy->ux_hcd_synergy_base)
        {
            payload_length = (ULONG)UX_SYNERGY_MAX_BULK_PAYLOAD;
        }
        else
#endif
        {
            /* Payload length is the buffer size.  */
            payload_length = data_buffer_size;
        }
    }      

    /* We need to select the FIFO registers.  */
    if (ed -> ux_synergy_fifo_index == UX_SYNERGY_HC_FIFO_D0)
    {
        /* Set fifo_sel and fifo_addr fields to FIFO_D0 */
        fifo_sel  =  UX_SYNERGY_HC_D0FIFOSEL;
        fifo_addr =  (VOID *) (hcd_synergy->ux_hcd_synergy_base + UX_SYNERGY_HC_D0FIFO);
        fifo_ctrl =  UX_SYNERGY_HC_D0FIFOCTR;
    }
    else
    {
        /* Set fifo_sel and fifo_addr fields to FIFO_D1 */
        fifo_sel  =  UX_SYNERGY_HC_D1FIFOSEL;
        fifo_addr =  (VOID *) (hcd_synergy->ux_hcd_synergy_base + UX_SYNERGY_HC_D1FIFO);
        fifo_ctrl =  UX_SYNERGY_HC_D1FIFOCTR;
    }

    /* Get the payload buffer address.  */
    payload_buffer =  td -> ux_synergy_td_buffer;

    /* Clear FIFO before the use to discard possible remaining data in the previous transfer.  */
    ux_hcd_synergy_register_set(hcd_synergy, fifo_ctrl, UX_SYNERGY_HC_FIFOCTR_BCLR );

    /* Check we can use DMA for data transfer.  */
    if(hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_tx != 0U)
    {
        /* Set transfer size.  */
#if defined(R_USBHS_BASE)
        if (R_USBHS_BASE == hcd_synergy->ux_hcd_synergy_base)
        {
            if(((UINT)payload_buffer % 4) == 0)
            {
                /* We use 32 bits to transfer.  */
                 transfer_length_width = 4UL;
                 hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->size   = TRANSFER_SIZE_4_BYTE;
                 hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length = (uint16_t)(payload_length / 4UL);
                 payload_length -=  (ULONG)(hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length * 4U);

                 /* Set FIFO access width to 32 bits. */
                 ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
                 ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_32);
            }
            else if(((UINT)payload_buffer % 2) == 0)
            {
                /* We use 16 bits to transfer.  */
                transfer_length_width = 2UL;
                hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->size   = TRANSFER_SIZE_2_BYTE;
                hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length = (uint16_t)(payload_length / 2UL);
                payload_length -= (ULONG)(hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length * 2U);

                /* Set FIFO access width to 16 bits. */
                ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
                ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_16);

                /* Align the FIFO address to 16-bit */
                fifo_addr = (VOID *) ((ULONG) fifo_addr + 2UL);
            }
            else
            {
                if(payload_length > 1024UL)
                {
                    /* Exceeds DMA transfer limit for block mode so do software copy */
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length = (uint16_t) (0);
                    ux_hcd_synergy_fifo_write_software_copy(hcd_synergy,
                            payload_length, payload_buffer, fifo_addr, fifo_sel);
                    payload_length = (ULONG) (0);
                }
                else
                {
                    /* We use 8 bits to transfer.  */
                    transfer_length_width = 1UL;
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->size   = TRANSFER_SIZE_1_BYTE;
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length = (uint16_t) payload_length;
                    payload_length -= (ULONG) hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length;

                    /* Set FIFO access width to 8 bits. */
                    ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
                    ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_8);

                    /* Align the FIFO address to 8-bit */
                    fifo_addr = (VOID *) ((ULONG) fifo_addr + 3UL);
                }
            }
        }
        else
#endif
        {
            if(((UINT)payload_buffer % 2) == 0)
            {
                /* We use 16 bits to transfer.  */
                transfer_length_width = 2UL;
                hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->size   = TRANSFER_SIZE_2_BYTE;
                hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length = (uint16_t)(payload_length / 2UL);
                payload_length -= (ULONG)(hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length * 2U);

                /* Set FIFO access width to 16 bits. */
                ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
                ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_16);

#if defined(R_USBHS_BASE)
                /* This needs for 16-bit write for USBHS. */
                if (R_USBHS_BASE == hcd_synergy->ux_hcd_synergy_base)
                {
                    fifo_addr = (VOID *) ((ULONG) fifo_addr + 2UL);
                }
#endif
            }
            else
            {
                 /* We use 8 bits to transfer.  */
                 transfer_length_width = 1UL;
                 hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->size   = TRANSFER_SIZE_1_BYTE;
                 hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length = (uint16_t) payload_length;
                 payload_length -= (ULONG) hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length;

                 /* Set FIFO access width to 8 bits. */
                 ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
                 ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_8);

#if defined(R_USBHS_BASE)
                /* This needs for 8-bit write for USBHS. */
                if (R_USBHS_BASE == hcd_synergy->ux_hcd_synergy_base)
                {
                    fifo_addr = (VOID *) ((ULONG) fifo_addr + 3UL);
                }
#endif
            }
        }

        /* Check if we have at least 4bytes for 32-bit access or 2bytes for 16-bit access to do DMA transfer,
         * else do software copy to avoid software overhead required for DMA operation. */
        if(hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length != 0U)
        {
            /* Setup DMA. */
            hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_tx->p_api->blockReset(
                    hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_tx->p_ctrl,
                    payload_buffer,
                    fifo_addr,
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length,
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_tx.p_info->size,
                    1);

            /* Trigger DMA by software control. */
            hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_tx->p_api->start(
                    hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_tx->p_ctrl,
                    TRANSFER_START_MODE_SINGLE);

            /* Wait until current DMA transfer completes. */
            _ux_utility_semaphore_get(&hcd_synergy->ux_hcd_synergy_semaphore_tx, UX_WAIT_FOREVER);
        }

        /* Update the payload buffer address after DMA transfer*/
        payload_buffer += ((ULONG)hcd_synergy->
                ux_hcd_synergy_transfer_cfg_instance_tx.p_info->length * transfer_length_width);

        if(payload_length != 0UL)
        {
             /* Reset the fifo address*/
             fifo_addr =  (VOID *) (hcd_synergy->ux_hcd_synergy_base + UX_SYNERGY_HC_D0FIFO);
             ux_hcd_synergy_fifo_write_software_copy_remaining_bytes(hcd_synergy, payload_length, payload_buffer,
                                                                    fifo_addr);

        }
    }
    else
    {
        /* Use software copy for data transfer. */
        ux_hcd_synergy_fifo_write_software_copy(hcd_synergy, payload_length, payload_buffer, fifo_addr, fifo_sel);
    }

    /* Check status. If we have a short packet, we need to set the BVAL flag in the USB controller. */
    if (status != (UINT)UX_SYNERGY_HC_FIFO_WRITING)
    {
        /* Read the current FIFO control register.  */
        synergy_register = ux_hcd_synergy_register_read(hcd_synergy, fifo_ctrl);

        /* Check if the BVAL bit is already set.  */
        if ((synergy_register & UX_SYNERGY_HC_FIFOCTR_BVAL) == 0UL)
        {
            /* No so set it.  This will enable the Buffer Memory Valid flag.
               This bit is set to 1 when data has been written to the FIFO and
               this is a short packet or zero packet or a full packet but not the
               end of the transmission.  */
            ux_hcd_synergy_register_set(hcd_synergy, fifo_ctrl, UX_SYNERGY_HC_FIFOCTR_BVAL);
        }
    }

    /* Return status about buffer transfer.  */
    return (UINT)status;
}
/*******************************************************************************************************************//**
 * @} (end addtogroup sf_el_ux)
 **********************************************************************************************************************/
