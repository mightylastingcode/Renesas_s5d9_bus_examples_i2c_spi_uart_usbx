/**************************************************************************/ 
/*                                                                        */ 
/*            Copyright (c) 1996-2012 by Express Logic Inc.               */ 
/*                                                                        */ 
/*  This software is copyrighted by and is the sole property of Express   */ 
/*  Logic, Inc.  All rights, title, ownership, or other interests         */ 
/*  in the software remain the property of Express Logic, Inc.  This      */ 
/*  software may only be used in accordance with the corresponding        */ 
/*  license agreement.  Any unauthorized use, duplication, transmission,  */ 
/*  distribution, or disclosure of this software is expressly forbidden.  */ 
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */ 
/*  written consent of Express Logic, Inc.                                */ 
/*                                                                        */ 
/*  Express Logic, Inc. reserves the right to modify this software        */ 
/*  without notice.                                                       */ 
/*                                                                        */ 
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               www.expresslogic.com          */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/

/***********************************************************************************************************************
 * Copyright [2017] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 * 
 * This file is part of Renesas SynergyTM Software Package (SSP)
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas SSP license agreement. Unless otherwise agreed in an SSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
 **********************************************************************************************************************/

/**************************************************************************/
/**************************************************************************/
/**                                                                       */ 
/** USBX Component                                                        */ 
/**                                                                       */
/**   SYNERGY Controller Driver                                           */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/


/* Include necessary system files.  */

#define UX_SOURCE_CODE

#include "ux_api.h"
#include "ux_hcd_synergy.h"
#include "ux_utility.h"

/*******************************************************************************************************************//**
 * @addtogroup sf_el_ux
 * @{
 **********************************************************************************************************************/

/**************************************************************************/ 
/*                                                                        */ 
/*  FUNCTION                                               RELEASE        */ 
/*                                                                        */ 
/*    ux_hcd_synergy_asynch_queue_process                 PORTABLE C      */
/*                                                           5.6          */ 
/*  AUTHOR                                                                */ 
/*                                                                        */ 
/*    Thierry Giron, Express Logic Inc.                                   */ 
/*                                                                        */ 
/*  DESCRIPTION                                                           */ 
/*                                                                        */ 
/*    This function process the asynchronous transactions that happened   */ 
/*    in the last frame. We read the ATL buffer and search for completed  */ 
/*    PTDs and reflect the completion in the higher level ED/TD.          */ 
/*                                                                        */ 
/*  INPUT                                                                 */ 
/*                                                                        */ 
/*    hcd_synergy                     Pointer to Synergy controller       */
/*                                                                        */ 
/*  OUTPUT                                                                */ 
/*                                                                        */ 
/*    None                                                                */ 
/*                                                                        */ 
/*  CALLS                                                                 */ 
/*                                                                        */ 
/*    (ux_transfer_request_completion_function) Transfer req completion   */ 
/*    ux_hcd_synergy_atl_buffer_read            Read to the ATL buffer    */
/*    ux_hcd_synergy_ed_td_clean                Clean Synergy TD          */
/*    ux_hcd_synergy_hcer_register_read         Read Synergy HCER read    */
/*    _ux_utility_memory_copy               Copy memory block             */ 
/*    _ux_utility_semaphore_put             Put semaphore                 */ 
/*                                                                        */ 
/*  CALLED BY                                                             */ 
/*                                                                        */ 
/*    Synergy Controller Driver                                           */
/*                                                                        */ 
/*  RELEASE HISTORY                                                       */ 
/*                                                                        */ 
/*    DATE              NAME                      DESCRIPTION             */ 
/*                                                                        */ 
/*  10-10-2012     TCRG                     Initial Version 5.6           */ 
/*  06-01-2014     TCRG                     Modified comment(s),          */ 
/*                                            resulting in version 5.7    */ 
/*  12-15-2016     TCRG                     Modified comment(s),          */ 
/*                                            resulting in version 5.7 SP7*/ 
/*                                                                        */ 
/**************************************************************************/ 

/***********************************************************************************************************************
 * Functions
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief  This function process the asynchronous transactions. The function will identify the USB interrupts
 *         occurred associated with an endpoint and will process the interrupts.
 *
 * @param[in,out]  hcd_synergy : Pointer to a HCD control block
 **********************************************************************************************************************/
VOID  ux_hcd_synergy_asynch_queue_process(UX_HCD_SYNERGY *hcd_synergy)
{
    UX_SYNERGY_ED     * ed;
    ULONG               ed_index;
    UX_SYNERGY_TD     * td;
    UX_SYNERGY_TD     * next_td;
    UX_TRANSFER       * transfer_request;


    /* Find the endpoint responsible for interrupt, map that to ed 
       find td that was scheduled, find out what happened on the transaction
       update the transaction. */
    
    /* Parse through the list of EDs */
    for (ed_index = 0UL ; ed_index <= 9UL ; ed_index++)
    {
        /* Check for an  event on the transaction. */
        if(hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index])
        { 
            /* There was something for the endpoint.  Load the ED that had a transmission.  */
            ed = hcd_synergy -> ux_hcd_synergy_ed_ptr[ed_index];

            /* Check if the irq  was a Buffer Ready.  */
            if( hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] & UX_SYNERGY_HC_ED_BRDY)
            {
                /* Process buffer ready interrupt. */
                ux_hcd_synergy_asynch_queue_process_brdy(hcd_synergy, ed);
            }

            if( hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] & UX_SYNERGY_HC_ED_NRDY )
            {
                /* Process buffer not ready interrupt. */
                ux_hcd_synergy_asynch_queue_process_nrdy(hcd_synergy, ed);
            }

            if( hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] & UX_SYNERGY_HC_ED_BEMP )
            {
                /* Process buffer empty interrupt. */
                ux_hcd_synergy_asynch_queue_process_bemp(hcd_synergy, ed);
            }

            if( hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] & UX_SYNERGY_HC_ED_EOFERR )
            {
                /* No definition */
            }

            if( hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] & UX_SYNERGY_HC_ED_SIGN  )
            {
                /* Process SIGN interrupt : Error on SETUP transfer. */
                ux_hcd_synergy_asynch_queue_process_sign(hcd_synergy, ed);
            }

            if( hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] &  UX_SYNERGY_HC_ED_SACK )
            {
                /* Clear the status flag. */
                hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] =
                        hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] & (~UX_SYNERGY_HC_ED_SACK);

                /* Get the TD associated with this transfer. */
                td = ed -> ux_synergy_ed_head_td;
 
                /* Take the TD out of the Endpoint.  */
                ed -> ux_synergy_ed_head_td =  td -> ux_synergy_td_next_td;
                
                /* We can now free the TD used in this PTD.  */
                td -> ux_synergy_td_status =  (ULONG)UX_UNUSED;
            }

            if( hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] &  UX_SYNERGY_HC_ED_TIMEOUT )
            {
                
                /* Clear the status flag. */
                hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] = hcd_synergy -> ux_hcd_synergy_ed_irq[ed_index] & (~UX_SYNERGY_HC_ED_TIMEOUT);

                /* Get the TD associated with this transfer. */
                td = ed -> ux_synergy_ed_head_td;

                /* Get the transfer request associated with the TD.  */
                transfer_request =  td -> ux_synergy_td_transfer_request;

                /* Ensure the interrupt was valid.  */
                if (td -> ux_synergy_td_status & UX_SYNERGY_TD_ACK_PENDING)
                {
                    /* Remove all the TDs attached.  */
                    while (td != ed -> ux_synergy_ed_tail_td)
                    {

                        /* Memorize this TD.  */
                        next_td =  td -> ux_synergy_td_next_td;

                        /* Take it out of the chain.  */
                        ed -> ux_synergy_ed_head_td =  next_td;
                        
                        /* We can now free the TD.  */
                        td -> ux_synergy_td_status =  (ULONG)UX_UNUSED;

                        /* Next TD.  */
                        td =  next_td;
                    }

                    /* Set the error code to TIMEOUT.  */
                    transfer_request -> ux_transfer_request_completion_code = (UINT)UX_TRANSFER_NO_ANSWER;
                    
                    /* Wake up the class if necessary.  */
                    if (transfer_request -> ux_transfer_request_completion_function != UX_NULL)
                    {
                        transfer_request -> ux_transfer_request_completion_function(transfer_request);
                    }

                    /* Wake up the transfer request thread.  */
                    _ux_utility_semaphore_put(&transfer_request -> ux_transfer_request_semaphore);
                } 
            }
        } 
    } 
}
/*******************************************************************************************************************//**
 * @} (end addtogroup sf_el_ux)
 **********************************************************************************************************************/

