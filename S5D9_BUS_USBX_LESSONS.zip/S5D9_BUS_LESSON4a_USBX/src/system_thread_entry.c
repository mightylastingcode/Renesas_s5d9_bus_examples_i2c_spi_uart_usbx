/*

    Project: Bus Lesson with USBX
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    12/28/17

    SSP version: 1.30
    E2 Studio version: 5.4.0.023

    Description: Use USB bus to serially communicate to the host (PC) in bidirectional mode.
                 Echo every received character back to the host.  If the received character is
                 <CR>, send "\r\n" to move to the next line of the terminal of the host.

    Requirement: Run the firmware in order for the USBX driver to be loaded into the window.
                 When loaded, you can use Window Device Manager to get the COM port assignment.
                 Use that assignment to set up your TERM software.

    Configuration: 9600 baud, No parity, integer sprintf.
*/
#include "system_thread.h"

char    msg_string[132];  // outgoing string
char    input_string[64];     // incoming string

#define RECEIVE_STRING_LENGTH 1
#define CR_CHARACTER          13

/* System Thread entry function */
void system_thread_entry(void)
{

    bool eol_flag;             // look for end of line char
    ssp_err_t ReturnVal;       // API error return

    /* LED type structure */
    bsp_leds_t leds;

    /* Get LED information for this board */
    R_BSP_LedsGet(&leds);

    /* If this board has no leds then trap here */
    if (0 == leds.led_count)
    {
        while(1);   // There are no leds on this board
    }
    /* Update all board LEDs */
    for(uint32_t i = 0; i < leds.led_count; i++)
    {
        g_ioport.p_api->pinWrite(leds.p_leds[i], IOPORT_LEVEL_LOW);

    }

    /* Interaction with the user via USB  */
    sprintf(msg_string, "Type %d character(s), they will be echoed back.  Press <return> when done.\r\n", RECEIVE_STRING_LENGTH);

     eol_flag = true;
     while (1)
     {
         /* send a message */

         if (eol_flag){
             ReturnVal = g_sf_comms0.p_api->write(g_sf_comms0.p_ctrl, (unsigned char *)msg_string, strlen(msg_string), TX_WAIT_FOREVER);
             if (SSP_SUCCESS != ReturnVal)
             {
                 g_ioport.p_api->pinWrite(leds.p_leds[1],IOPORT_LEVEL_HIGH);
                 while(1);
             }
             eol_flag = false;   // force the loop to keep reading until an end-of-line character is reached.
         }

         /* read some characters */
         memset(input_string, 0, sizeof(input_string));   // clear buffer

         /* read buffer one character at a time */
         ReturnVal = g_sf_comms0.p_api->read(g_sf_comms0.p_ctrl, (unsigned char *)input_string, RECEIVE_STRING_LENGTH, TX_WAIT_FOREVER);
         if (SSP_SUCCESS != ReturnVal)
         {
             g_ioport.p_api->pinWrite(leds.p_leds[1],IOPORT_LEVEL_HIGH);
             while(1);
         }

         /* Append carriage return and new line to buffer */
         if (CR_CHARACTER == input_string[0]) {
             sprintf(input_string + RECEIVE_STRING_LENGTH, "\r\n");  // append to the end of the location designated by input_string
                                                                    // + RECEIVE_STRING_LENGTH
             eol_flag = true;
         }

         /* echo back the received character back to the host */
         ReturnVal = g_sf_comms0.p_api->write(g_sf_comms0.p_ctrl, (unsigned char *)input_string, strlen(input_string), TX_WAIT_FOREVER);
         if (SSP_SUCCESS != ReturnVal)
         {
             while(1);
         }
         tx_thread_sleep (10);
     }


}
